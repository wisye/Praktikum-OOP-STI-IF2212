import java.util.Stack;

public class Box {
    private Stack<Shirt> items;

    public Box() {
        // Menginisialisasi items
    }
    
    public void addItem(Shirt item) {
        // Menambahkan item ke dalam items
    }

    public void removeItem() {
        // Menghapus item dari items
    }

    public Stack<Shirt> getItems() {
        // Mengembalikan list of items
    }

    public boolean isEmpty() {
        // Mengembalikan true jika items kosong
    }
}