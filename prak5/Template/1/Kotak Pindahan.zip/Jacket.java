public class Jacket {
    public String jacketColor;

    public Jacket(String color) {
        this.jacketColor = color;
    }
}