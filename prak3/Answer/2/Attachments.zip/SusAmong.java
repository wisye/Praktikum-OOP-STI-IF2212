import java.util.Scanner;

import javax.swing.text.PlainDocument;

public class SusAmong {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int totalPlayer = s.nextInt();
		int compost = s.nextInt();

		Player[] players = new Player[totalPlayer];

		for(int i = 0; i < compost; i++){
			RedAstronaut ra = new RedAstronaut("Crewmate " + (i+1)); 
			players[i] = ra;
		}
		for(int i = compost; i < totalPlayer; i++){
			BlueAstronaut ba = new BlueAstronaut("Crewmate " + (i+1) );
			players[i] = ba;
		}
		
		int completedTask = 0;
		int emergencyMeetingCalled = 0;
		int playersFrozen = 0;

		while(true){
			int com = s.nextInt();
			if(com == 1){
				int idx = s.nextInt();
				if(players[idx] instanceof BlueAstronaut){
					BlueAstronaut ba = (BlueAstronaut) players[idx];
					int sus = ba.getSusLevel();
					ba.completeTask();
					if(sus != ba.getSusLevel()){
						completedTask++;
					}
				}
			}
			else if(com == 2){
				int idxRed = s.nextInt();
				int idxBlue = s.nextInt();

				if(players[idxRed] instanceof RedAstronaut && players[idxBlue] instanceof BlueAstronaut){
					RedAstronaut ra = (RedAstronaut) players[idxRed];
					BlueAstronaut ba = (BlueAstronaut) players[idxBlue];
					ra.freeze(ba);
					if(ba.isFrozen()){
						playersFrozen++;
					}
				}
			}
			else if(com == 3){
				RedAstronaut ra = new RedAstronaut("FURINA");
				ra.emergencyMeeting();
				emergencyMeetingCalled++;
				int countFrozen = 0;
				for (int i = 0; i < totalPlayer; i++) {
					if(players[i].isFrozen()){
						countFrozen++;
					}
				}
				if(countFrozen > playersFrozen){
					playersFrozen = countFrozen;
				}
				if(ra.gameOver()){
					System.out.println("Task completed: " + completedTask);
					System.out.println("Players frozen: " + playersFrozen);
					System.out.println("Emergency meetings called: " + emergencyMeetingCalled);
					System.out.println("Game Over. Thanks for playing!");
					break;
				}
			}
			else if(com == 4){
				System.out.println("Task completed: " + completedTask);
				System.out.println("Players frozen: " + playersFrozen);
				System.out.println("Emergency meetings called: " + emergencyMeetingCalled);
				System.out.println("Game Over. Thanks for playing!");
				break; 
			}
		}
		s.close();
	}
}
